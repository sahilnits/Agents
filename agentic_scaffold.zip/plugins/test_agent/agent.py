
from typing import Any
class TestAgent:
    """Example Test agent."""
    def run(self, *args, **kwargs) -> Any:
        return "TestAgent ran successfully"
