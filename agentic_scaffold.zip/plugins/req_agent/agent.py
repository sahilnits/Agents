
from typing import Any
class ReqAgent:
    """Example Requirement agent."""
    def run(self, *args, **kwargs) -> Any:
        return "ReqAgent ran successfully"
